#!/usr/bin/env python3
"""Per-request and per-unit API-equivalent cost for sprint RUN-01M6QYF8.

Usage: python3 requests_by_unit.py

Sources:
  - Cursor usage exports, de-duplicated by Billing Item ID.
  - Unit merge times from GitHub PR merged_at (the consuming project's repository).
  - Points from sprint-plan.md; BG0682+BG0683 (5 pts) and extra-release (0 pts)
    are extra to the 100-point plan.

Pricing (grok-4.7, per 1M tokens): input $2, cached $0.50, output $6.
Cache-write is billed as input. If uncached+cached+cache-write >= 200k, the
whole request bills at 2x.

Attribution is by event-time window: previous unit merge (or batch/run start)
<= t < this unit's merged_at. Requests outside a unit window go to a labelled
overhead bucket on that batch.

Important limitation: until 9 Nov 08:15 UTC, many Cursor events share a single
run-start timestamp, so a run that covers several units cannot be split. Those
runs are labelled unattributed:* rather than assigned to one unit. From 9 Nov
08:15, and for batches A–C, each request has its own timestamp.
"""
from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sprint_cost import LC_THRESHOLD, STD, load, price, T

OUT = Path("<workdir>")
SOURCES = [
    OUT / "usage-full-2026-10-25_to_11-09.csv",
    Path("<downloads>/personal-unified-usage-2026-11-10.csv"),
    Path("<downloads>/usage-2026-11-09-eod.csv"),
]

SPRINT_START = T("2026-11-06T08:06:00Z")
# Export coverage ends at the last event in the Nov 10 file.
EXPORT_END = T("2026-11-10T11:42:00Z")

# (batch, unit, start, end, points, note)
# end is exclusive. Starts and ends are ISO UTC.
WINDOWS = [
    # --- Old single agent -------------------------------------------------
    ("old-single-agent", "overhead:planning",
     "2026-11-06T08:06:00Z", "2026-11-06T08:26:15.773Z", 0,
     "Planning run stamped 08:06:24. All 69 events share that timestamp."),
    ("old-single-agent", "unattributed:exec-A-08:26",
     "2026-11-06T08:26:15.773Z", "2026-11-06T11:43:50.956Z", 0,
     "Run-start stamp 08:26:15 covers BG0680, BG0681, BG0488 and BG0682+BG0683; cannot split."),
    ("old-single-agent", "unattributed:exec-A-11:43",
     "2026-11-06T11:43:50.956Z", "2026-11-06T13:53:38.421Z", 0,
     "Run-start stamp 11:43:50 covers BG0503, BG0521, BG0522 and BG0523; cannot split."),
    ("old-single-agent", "BG0524",
     "2026-11-06T13:53:38.421Z", "2026-11-06T14:33:36Z", 3,
     "PR #156 merged 14:33:36. Run stamp 13:53:38 plus flush at 14:32:49."),
    ("old-single-agent", "BG0528",
     "2026-11-06T14:33:36Z", "2026-11-06T15:10:36Z", 2,
     "PR #157 merged 15:10:36."),
    ("old-single-agent", "BG0532",
     "2026-11-06T15:10:36Z", "2026-11-06T16:09:54Z", 3,
     "PR #158 merged 16:09:54."),
    ("old-single-agent", "overhead:end-of-day",
     "2026-11-06T16:09:54Z", "2026-11-07T17:25:35.095Z", 0,
     "Post-BG0532 flush at 16:27:05, then idle."),
    ("old-single-agent", "overhead:nudge",
     "2026-11-07T17:25:35.095Z", "2026-11-08T18:16:18.803Z", 0,
     "Nudge run stamped 17:25:35. Five events, no unit merged."),
    ("old-single-agent", "BG0539",
     "2026-11-08T18:16:18.803Z", "2026-11-08T18:44:05Z", 2, "PR #159 merged 18:44:05."),
    ("old-single-agent", "BG0540",
     "2026-11-08T18:44:05Z", "2026-11-08T19:36:52Z", 2, "PR #160 merged 19:36:52."),
    ("old-single-agent", "BG0541",
     "2026-11-08T19:36:52Z", "2026-11-08T20:23:31Z", 2, "PR #161 merged 20:23:31."),
    ("old-single-agent", "BG0543",
     "2026-11-08T20:23:31Z", "2026-11-08T21:00:07Z", 3, "PR #162 merged 21:00:07."),
    ("old-single-agent", "BG0544",
     "2026-11-08T21:00:07Z", "2026-11-08T21:50:41Z", 2, "PR #163 merged 21:50:41."),
    ("old-single-agent", "BG0548",
     "2026-11-08T21:50:41Z", "2026-11-08T22:34:42Z", 2, "PR #164 merged 22:34:42."),
    ("old-single-agent", "BG0550",
     "2026-11-08T22:34:42Z", "2026-11-08T23:19:07Z", 5, "PR #165 merged 23:19:07."),
    ("old-single-agent", "BG0558",
     "2026-11-08T23:19:07Z", "2026-11-09T00:04:28Z", 3, "PR #166 merged 00:04:28."),
    ("old-single-agent", "BG0560",
     "2026-11-09T00:04:28Z", "2026-11-09T00:57:01Z", 3, "PR #167 merged 00:57:01."),
    ("old-single-agent", "BG0461",
     "2026-11-09T00:57:01Z", "2026-11-09T01:33:42Z", 2, "PR #168 merged 01:33:42."),
    ("old-single-agent", "BG0512",
     "2026-11-09T01:33:42Z", "2026-11-09T02:35:11Z", 2, "PR #169 merged 02:35:11."),
    ("old-single-agent", "BG0515",
     "2026-11-09T02:35:11Z", "2026-11-09T03:14:03Z", 2, "PR #170 merged 03:14:03."),
    ("old-single-agent", "BG0520",
     "2026-11-09T03:14:03Z", "2026-11-09T04:02:40Z", 2, "PR #171 merged 04:02:40."),
    ("old-single-agent", "overhead:session-end",
     "2026-11-09T04:02:40Z", "2026-11-09T08:15:29.223Z", 0,
     "Flush at 04:19:47 after BG0520 merge, then overnight gap."),
    ("old-single-agent", "BG0527",
     "2026-11-09T08:15:29.223Z", "2026-11-09T08:34:31Z", 2,
     "PR #172 merged 08:34:31. Per-request timestamps begin here."),
    ("old-single-agent", "BG0529",
     "2026-11-09T08:34:31Z", "2026-11-09T09:23:04Z", 2, "PR #173 merged 09:23:04."),
    ("old-single-agent", "BG0559",
     "2026-11-09T09:23:04Z", "2026-11-09T09:59:39Z", 2, "PR #174 merged 09:59:39."),
    ("old-single-agent", "extra-release",
     "2026-11-09T09:59:39Z", "2026-11-09T10:36:40Z", 0,
     "PR #175, not in the 100-point plan."),
    ("old-single-agent", "BG0573",
     "2026-11-09T10:36:40Z", "2026-11-09T11:29:12Z", 2, "PR #176 merged 11:29:12."),
    ("old-single-agent", "BG0598",
     "2026-11-09T11:29:12Z", "2026-11-09T12:10:23Z", 2, "PR #177 merged 12:10:23."),
    ("old-single-agent", "BG0605",
     "2026-11-09T12:10:23Z", "2026-11-09T12:55:03Z", 2, "PR #178 merged 12:55:03."),
    ("old-single-agent", "BG0606",
     "2026-11-09T12:55:03Z", "2026-11-09T13:32:02Z", 1, "PR #179 merged 13:32:02. Last planned unit of the old agent."),
    ("old-single-agent", "overhead:handoff",
     "2026-11-09T13:32:02Z", "2026-11-09T13:54:49.739Z", 0,
     "Handoff run 13:32–13:54 after BG0606."),
    # --- Batch A ----------------------------------------------------------
    ("batch-A", "BG0607",
     "2026-11-09T13:54:49.739Z", "2026-11-09T14:27:49Z", 2,
     "PR #180 merged 14:27:49. First billed request of the new agent is 13:54:49 (context reset), slightly before the 13:56:14 launch time."),
    ("batch-A", "BG0634",
     "2026-11-09T14:27:49Z", "2026-11-09T15:09:42Z", 2, "PR #181 merged 15:09:42."),
    ("batch-A", "BG0675",
     "2026-11-09T15:09:42Z", "2026-11-09T15:46:38Z", 2, "PR #182 merged 15:46:38."),
    ("batch-A", "BG0516",
     "2026-11-09T15:46:38Z", "2026-11-09T16:45:18Z", 1, "PR #183 merged 16:45:18."),
    ("batch-A", "BG0530",
     "2026-11-09T16:45:18Z", "2026-11-09T17:24:47Z", 1, "PR #184 merged 17:24:47."),
    ("batch-A", "overhead:handoff",
     "2026-11-09T17:24:47Z", "2026-11-09T17:41:32.552Z", 0,
     "Handoff after BG0530. Includes the 17:36:31–17:37:41 cluster after the 17:36:54 time quoted earlier."),
    # --- Batch B run 1 (local prep, no merges) ----------------------------
    ("batch-B-run1", "overhead:prep",
     "2026-11-09T17:41:32.552Z", "2026-11-10T08:43:41.659Z", 0,
     "Local prep for BG0549/0554/0509/0594/0648. No merge in this run. Includes 3 requests at 18:23:01–18:23:16 after the 18:23:00 cutoff used for the cited $9.44."),
    # --- Batch B run 2 ----------------------------------------------------
    ("batch-B-run2", "BG0549",
     "2026-11-10T08:43:41.659Z", "2026-11-10T08:43:46Z", 1,
     "PR #185 merged 08:43:46, almost at run start. Coding was in run 1. Two post-merge requests at 08:43:56 and 08:44:01 fall into BG0554."),
    ("batch-B-run2", "BG0554",
     "2026-11-10T08:43:46Z", "2026-11-10T09:30:19Z", 1, "PR #186 merged 09:30:19."),
    ("batch-B-run2", "BG0509",
     "2026-11-10T09:30:19Z", "2026-11-10T10:08:39Z", 1, "PR #187 merged 10:08:39."),
    ("batch-B-run2", "BG0594",
     "2026-11-10T10:08:39Z", "2026-11-10T10:45:05Z", 1, "PR #188 merged 10:45:05."),
    ("batch-B-run2", "BG0648",
     "2026-11-10T10:45:05Z", "2026-11-10T11:21:58Z", 1, "PR #189 merged 11:21:58."),
    ("batch-B-run2", "overhead:handoff",
     "2026-11-10T11:21:58Z", "2026-11-10T11:41:33.474Z", 0,
     "Handoff after BG0648. Includes 11:40:38–11:40:48 (in the cited $12.92) and 11:41:12 (same session, just after 11:41:00)."),
    # --- Batch C (export ends almost immediately) -------------------------
    ("batch-C", "overhead:orientation",
     "2026-11-10T11:41:33.474Z", "2026-11-10T11:42:00Z", 0,
     "First request of a new agent (context reset to 27k). BG0656 PR was opened at 11:56, after this export ends. Batch C is not covered."),
]

# Units whose costs sit in an unattributed run (delivered, but not separable).
COVERED_BUT_UNSPLIT = [
    ("old-single-agent", "BG0680", 5, "unattributed:exec-A-08:26", "PR #148 merged 09:01:08."),
    ("old-single-agent", "BG0681", 3, "unattributed:exec-A-08:26", "PR #149 merged 09:38:42."),
    ("old-single-agent", "BG0488", 3, "unattributed:exec-A-08:26", "PR #150 merged 10:34:46."),
    ("old-single-agent", "BG0682+BG0683", 5, "unattributed:exec-A-08:26",
     "PR #151 merged 11:10:02. Extra to the 100-point plan; 5 pts from the earlier sprint-cost attribution."),
    ("old-single-agent", "BG0503", 3, "unattributed:exec-A-11:43", "PR #152 merged 11:52:11."),
    ("old-single-agent", "BG0521", 3, "unattributed:exec-A-11:43", "PR #153 merged 12:32:23."),
    ("old-single-agent", "BG0522", 2, "unattributed:exec-A-11:43", "PR #154 merged 13:09:05."),
    ("old-single-agent", "BG0523", 2, "unattributed:exec-A-11:43", "PR #155 merged 13:48:02."),
]


def event_time(row: dict) -> str:
    return row.get("Event Time") or row.get("Event Time (UTC)") or ""


def tokens(row: dict):
    raw = row.get("Usage") or "{}"
    u = json.loads(raw) if raw else {}
    def n(key):
        v = u.get(key, 0)
        return int(v) if v not in (None, "") else 0
    return (
        n("prompt-text-tokens"),
        n("cached-prompt-text-tokens"),
        n("cache-write-text-tokens"),
        n("completion-text-tokens"),
    )


def assign(t: datetime, windows):
    for batch, unit, lo, hi, pts, note in windows:
        if lo <= t < hi:
            return batch, unit, pts, note
    return None, None, 0, ""


def accumulate():
    return dict(requests=0, long_context_requests=0,
                uncached=0, cached=0, cache_write=0, output=0,
                cost_usd=0.0)


def add(agg, p, c, w, o, cost, lc):
    agg["requests"] += 1
    agg["long_context_requests"] += int(lc)
    agg["uncached"] += p
    agg["cached"] += c
    agg["cache_write"] += w
    agg["output"] += o
    agg["cost_usd"] += cost


def money(x: float) -> str:
    return f"{x:.2f}"


def main():
    windows = [(b, u, T(lo), T(hi), pts, note) for b, u, lo, hi, pts, note in WINDOWS]
    # Sanity: windows should be contiguous from SPRINT_START to EXPORT_END.
    prev_hi = SPRINT_START
    for batch, unit, lo, hi, pts, note in windows:
        if lo != prev_hi:
            print(f"WARNING: gap or overlap before {batch}/{unit}: prev_hi={prev_hi.isoformat()} lo={lo.isoformat()}")
        if hi <= lo:
            print(f"WARNING: empty window {batch}/{unit}")
        prev_hi = hi
    if prev_hi != EXPORT_END:
        print(f"NOTE: last window ends {prev_hi.isoformat()}, export_end={EXPORT_END.isoformat()}")

    rows = load([str(p) for p in SOURCES if p.exists()])
    cursor, bot = [], []
    for r in rows:
        t = event_time(r)
        if not t:
            continue
        dt = T(t)
        if dt < SPRINT_START or dt >= EXPORT_END:
            continue
        if r["Product"] == "cursor":
            cursor.append(r)
        elif r["Product"] == "grok-bot":
            bot.append(r)

    cursor.sort(key=lambda r: event_time(r))
    bot.sort(key=lambda r: event_time(r))

    req_path = OUT / "requests-by-unit.csv"
    fieldnames = [
        "event_time_utc", "batch", "agent_id", "unit",
        "uncached", "cached", "cache_write", "output",
        "prompt_total", "long_context", "cost_usd",
    ]
    request_rows = []
    unmatched = []
    unit_agg = defaultdict(accumulate)
    batch_cursor = defaultdict(accumulate)
    batch_overhead = defaultdict(accumulate)
    batch_unattr = defaultdict(accumulate)
    batch_units = defaultdict(accumulate)

    for r in cursor:
        ts = event_time(r)
        dt = T(ts)
        p, c, w, o = tokens(r)
        prompt_total = p + c + w
        lc = prompt_total >= LC_THRESHOLD
        cost = price(p, c, w, o)
        batch, unit, pts, note = assign(dt, windows)
        if batch is None:
            unmatched.append(ts)
            batch, unit = "unassigned", "overhead"
        rec = {
            "event_time_utc": ts,
            "batch": batch,
            "agent_id": "",  # export has no per-agent column
            "unit": unit,
            "uncached": p,
            "cached": c,
            "cache_write": w,
            "output": o,
            "prompt_total": prompt_total,
            "long_context": "true" if lc else "false",
            "cost_usd": f"{cost:.8f}",
        }
        request_rows.append(rec)
        key = (batch, unit)
        add(unit_agg[key], p, c, w, o, cost, lc)
        add(batch_cursor[batch], p, c, w, o, cost, lc)
        if unit.startswith("overhead:"):
            add(batch_overhead[batch], p, c, w, o, cost, lc)
        elif unit.startswith("unattributed:"):
            add(batch_unattr[batch], p, c, w, o, cost, lc)
        else:
            add(batch_units[batch], p, c, w, o, cost, lc)

    with req_path.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=fieldnames)
        wri.writeheader()
        wri.writerows(request_rows)

    # units-summary: window units (in order) plus placeholder rows for unsplit units.
    points_by = {(b, u): pts for b, u, *_, pts, __ in WINDOWS}
    notes_by = {(b, u): note for b, u, *_, note in WINDOWS}

    unit_fields = [
        "batch", "unit", "points", "requests", "long_context_requests",
        "uncached", "cached", "cache_write", "output", "prompt_total",
        "cost_usd", "cost_per_point",
    ]
    unit_rows = []
    seen = set()
    for batch, unit, lo, hi, pts, note in WINDOWS:
        key = (batch, unit)
        seen.add(key)
        a = unit_agg.get(key, accumulate())
        prompt_total = a["uncached"] + a["cached"] + a["cache_write"]
        cpp = "" if pts <= 0 or a["requests"] == 0 else f"{a['cost_usd'] / pts:.4f}"
        # Unattributed runs have points=0 here; the covered units are listed separately.
        unit_rows.append({
            "batch": batch,
            "unit": unit,
            "points": pts,
            "requests": a["requests"],
            "long_context_requests": a["long_context_requests"],
            "uncached": a["uncached"],
            "cached": a["cached"],
            "cache_write": a["cache_write"],
            "output": a["output"],
            "prompt_total": prompt_total,
            "cost_usd": money(a["cost_usd"]),
            "cost_per_point": cpp,
        })
    for batch, unit, pts, bucket, note in COVERED_BUT_UNSPLIT:
        unit_rows.append({
            "batch": batch,
            "unit": unit,
            "points": pts,
            "requests": 0,
            "long_context_requests": 0,
            "uncached": 0,
            "cached": 0,
            "cache_write": 0,
            "output": 0,
            "prompt_total": 0,
            "cost_usd": "",
            "cost_per_point": "",
        })

    units_path = OUT / "units-summary.csv"
    with units_path.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=unit_fields)
        wri.writeheader()
        wri.writerows(unit_rows)

    # Grok-bot coordinator, by batch (same time windows, no unit split).
    batch_bot = defaultdict(accumulate)
    bot_unassigned = accumulate()
    for r in bot:
        ts = event_time(r)
        dt = T(ts)
        p, c, w, o = tokens(r)
        lc = (p + c + w) >= LC_THRESHOLD
        cost = price(p, c, w, o)
        batch, unit, pts, note = assign(dt, windows)
        if batch is None:
            add(bot_unassigned, p, c, w, o, cost, lc)
        else:
            add(batch_bot[batch], p, c, w, o, cost, lc)

    batch_order = []
    for batch, unit, lo, hi, pts, note in WINDOWS:
        if batch not in batch_order:
            batch_order.append(batch)

    batch_fields = [
        "batch", "category", "requests", "long_context_requests",
        "uncached", "cached", "cache_write", "output", "prompt_total",
        "cost_usd",
    ]

    def brow(batch, category, a):
        return {
            "batch": batch,
            "category": category,
            "requests": a["requests"],
            "long_context_requests": a["long_context_requests"],
            "uncached": a["uncached"],
            "cached": a["cached"],
            "cache_write": a["cache_write"],
            "output": a["output"],
            "prompt_total": a["uncached"] + a["cached"] + a["cache_write"],
            "cost_usd": money(a["cost_usd"]),
        }

    batch_rows = []
    tot_cursor, tot_units, tot_oh, tot_un, tot_bot = (accumulate() for _ in range(5))
    for batch in batch_order:
        cu, un, oh, ua, bo = (batch_cursor[batch], batch_units[batch],
                              batch_overhead[batch], batch_unattr[batch], batch_bot[batch])
        batch_rows.append(brow(batch, "cloud-agent:total", cu))
        batch_rows.append(brow(batch, "cloud-agent:units", un))
        batch_rows.append(brow(batch, "cloud-agent:overhead", oh))
        batch_rows.append(brow(batch, "cloud-agent:unattributed", ua))
        batch_rows.append(brow(batch, "grok-bot:coordinator", bo))
        for src, dst in ((cu, tot_cursor), (un, tot_units), (oh, tot_oh), (ua, tot_un), (bo, tot_bot)):
            dst["requests"] += src["requests"]
            dst["long_context_requests"] += src["long_context_requests"]
            dst["uncached"] += src["uncached"]
            dst["cached"] += src["cached"]
            dst["cache_write"] += src["cache_write"]
            dst["output"] += src["output"]
            dst["cost_usd"] += src["cost_usd"]

    batch_rows.append(brow("ALL", "cloud-agent:total", tot_cursor))
    batch_rows.append(brow("ALL", "cloud-agent:units", tot_units))
    batch_rows.append(brow("ALL", "cloud-agent:overhead", tot_oh))
    batch_rows.append(brow("ALL", "cloud-agent:unattributed", tot_un))
    batch_rows.append(brow("ALL", "grok-bot:coordinator", tot_bot))
    if bot_unassigned["requests"]:
        batch_rows.append(brow("unassigned", "grok-bot:coordinator", bot_unassigned))

    batches_path = OUT / "batches-summary.csv"
    with batches_path.open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=batch_fields)
        wri.writeheader()
        wri.writerows(batch_rows)

    # Reconciliation against previously cited figures.
    def window_cost(lo, hi, product="cursor"):
        lo, hi = T(lo), T(hi)
        n, cost, lc = 0, 0.0, 0
        src = cursor if product == "cursor" else bot
        first = last = None
        for r in src:
            dt = T(event_time(r))
            if lo <= dt < hi:
                p, c, w, o = tokens(r)
                n += 1
                cost += price(p, c, w, o)
                lc += (p + c + w) >= LC_THRESHOLD
                first = first or event_time(r)
                last = event_time(r)
        return n, cost, lc, first, last

    checks = [
        ("sprint to 74 pts (08:06:00 <= t < 13:40:38 9 Nov, as in the 13:40 export)",
         "2026-11-06T08:06:00Z", "2026-11-09T13:40:38Z", 2161, 280.63),
        ("old agent through handoff (08:06:00 <= t < 13:54:49.739)",
         "2026-11-06T08:06:00Z", "2026-11-09T13:54:49.739Z", None, None),
        ("batch A (13:54:49.739 <= t < 17:41:32.552) — cited $25.72 / 321",
         "2026-11-09T13:54:49.739Z", "2026-11-09T17:41:32.552Z", 321, 25.72),
        ("batch A cited window as written (13:56:14 <= t < 17:36:54)",
         "2026-11-09T13:56:14Z", "2026-11-09T17:36:54Z", 321, 25.72),
        ("batch B run 1 (17:41:32.552 <= t < 08:43:41.659 10 Nov) — cited $9.44 / 110 was t < 18:23:00",
         "2026-11-09T17:41:32.552Z", "2026-11-10T08:43:41.659Z", 110, 9.44),
        ("batch B run 1 cutoff used for the cited figure (17:40:00 <= t < 18:23:00)",
         "2026-11-09T17:40:00Z", "2026-11-09T18:23:00Z", 110, 9.44),
        ("batch B run 2 (08:43:41.659 <= t < 11:41:33.474) — cited $12.92 / 110 was t < 11:41:00",
         "2026-11-10T08:43:41.659Z", "2026-11-10T11:41:33.474Z", 110, 12.92),
        ("batch B run 2 cutoff used for the cited figure (08:43:41.659 <= t < 11:41:00)",
         "2026-11-10T08:43:41.659Z", "2026-11-10T11:41:00Z", 110, 12.92),
        ("batch C in this export (11:41:33.474 <= t < 11:42:00)",
         "2026-11-10T11:41:33.474Z", "2026-11-10T11:42:00Z", None, None),
    ]

    recon_lines = []
    for label, lo, hi, exp_n, exp_c in checks:
        n, cost, lc, first, last = window_cost(lo, hi)
        delta = ""
        if exp_n is not None:
            dn, dc = n - exp_n, cost - exp_c
            delta = f"  vs cited {exp_n} / ${exp_c:.2f}: {dn:+d} req, {dc:+.2f} USD"
        recon_lines.append(
            f"- {label}: {n} requests, ${cost:.2f}, {lc} long-context, first={first}, last={last}.{delta}"
        )

    # Write windows + notes for the record.
    (OUT / "windows.json").write_text(json.dumps({
        "windows": [
            {"batch": b, "unit": u, "start": lo, "end": hi, "points": p, "note": n}
            for b, u, lo, hi, p, n in WINDOWS
        ],
        "covered_but_unsplit": [
            {"batch": b, "unit": u, "points": p, "cost_bucket": k, "note": n}
            for b, u, p, k, n in COVERED_BUT_UNSPLIT
        ],
    }, indent=2))

    # Human-readable batch summary.
    def md_table(headers, rows):
        line = "| " + " | ".join(headers) + " |"
        sep = "| " + " | ".join("---" for _ in headers) + " |"
        body = ["| " + " | ".join(str(c) for c in row) + " |" for row in rows]
        return "\n".join([line, sep, *body])

    def fmt_tok(n):
        return f"{n:,}"

    summary_rows = []
    for br in batch_rows:
        if br["batch"] == "ALL" or br["category"] in (
            "cloud-agent:total", "cloud-agent:units", "cloud-agent:overhead",
            "cloud-agent:unattributed", "grok-bot:coordinator",
        ):
            summary_rows.append((
                br["batch"], br["category"], br["requests"], br["long_context_requests"],
                fmt_tok(br["uncached"]), fmt_tok(br["cached"]), fmt_tok(br["cache_write"]),
                fmt_tok(br["output"]), f"${br['cost_usd']}",
            ))

    # Compact batch table for the parent report: one line per batch for cursor total, overhead, unattributed, grok-bot.
    compact = []
    for batch in batch_order + ["ALL"]:
        bycat = {r["category"]: r for r in batch_rows if r["batch"] == batch}
        tot = bycat["cloud-agent:total"]
        compact.append((
            batch,
            tot["requests"],
            f"${tot['cost_usd']}",
            f"${bycat['cloud-agent:units']['cost_usd']}",
            f"${bycat['cloud-agent:overhead']['cost_usd']}",
            f"${bycat['cloud-agent:unattributed']['cost_usd']}",
            bycat["grok-bot:coordinator"]["requests"],
            f"${bycat['grok-bot:coordinator']['cost_usd']}",
        ))

    md = f"""# RUN-01M6QYF8 raw cost data (API-equivalent)

Generated from the Cursor usage exports, de-duplicated by Billing Item ID, priced at grok-4.7 API rates (input $2, cached $0.50, output $6 per 1M tokens; cache-write billed as input; 2× when uncached+cached+cache-write ≥ 200k).

## Files

- `requests-by-unit.csv` — one row per cloud-agent (Product=cursor) request in the sprint window (6 Nov 08:06Z through the 10 Nov 11:41Z export).
- `units-summary.csv` — one row per unit window, plus placeholder rows for units whose cost could not be separated.
- `batches-summary.csv` — batch totals for cloud-agent units, overhead, unattributed runs, and grok-bot coordinator usage.
- `windows.json` and `requests_by_unit.py` — the windows and the generator.

`agent_id` is blank: the export has no per-agent column. Attribution is by time window only.

## Batch-level summary (cloud-agent USD, grok-bot separate)

| Batch | Cursor requests | Cursor cost | Of which units | Of which overhead | Of which unattributed | Grok-bot requests | Grok-bot cost |
| --- | --- | --- | --- | --- | --- | --- | --- |
"""
    for row in compact:
        md += "| " + " | ".join(str(x) for x in row) + " |\n"

    md += """
Grok-bot is coordinator overhead (all of the operator's bots, not only this sprint). It is priced at the same grok-4.7 rates so it can be compared, and is not included in the Cursor / per-unit figures.

## Reconciliation with previously cited figures

"""
    md += "\n".join(recon_lines)
    md += """

How to read the differences:

- The **$280.63 / 2,161** figure is exact for Cursor usage from 6 Nov 08:06Z to the 9 Nov 13:40Z export cutoff. The old agent's handoff continued until 13:53:57Z, which adds 20 requests and **$1.46** (old-agent Cursor total **$282.09**).
- **Batch A $25.72 / 321** matches when the window is the new agent's first billed request (13:54:49.739Z, a context reset) through 17:37:41Z, i.e. just before batch B run 1. The times quoted earlier (13:56:14Z–17:36:54Z) were slightly tight and omit 17 requests / $0.62 at the two ends.
- **Batch B run 1 $9.44 / 110** matches `t < 18:23:00Z`. The same run has three more requests at 18:23:01–18:23:16 ($0.66), so the full prep run is **113 requests / $10.10**. Those three belong to the run (prompt size still ~212k).
- **Batch B run 2 $12.92 / 110** matches `08:43:41.659Z <= t < 11:41:00Z`. One further request at 11:41:12Z ($0.06) is the same session and is included as batch-B-run2 handoff, so the batch total is **111 requests / $12.98**. The request at 11:41:33Z resets context to 27k and is the only batch-C event in this export ($0.05).
- Nothing was forced to match. Where a cited cutoff and the natural run boundary differ, both are shown.

## Caveats

1. **No per-agent column.** Every Cursor row in this window is grok-4.7-high on a single user principal (plus one empty `grok-bot-default` row at the 6 Nov 08:26:15 stamp, cost $0). Batches and units are assigned by time window only.
2. **Run-start stamping until 9 Nov 08:15Z.** On 6 Nov, 1,011 requests share 08:26:15.773Z and 171 share 11:43:50.956Z. Those runs each cover several merged units, so their cost is in `unattributed:exec-A-08:26` (BG0680, BG0681, BG0488, BG0682+BG0683) and `unattributed:exec-A-11:43` (BG0503, BG0521, BG0522, BG0523). From 9 Nov 08:15Z, and in batches A–C, each request has its own timestamp and merge-to-merge windows are meaningful.
3. **Batch C is not covered.** The export ends at 11:41:55Z. Only the first batch-C Cursor request (11:41:33Z, $0.05) is present. BG0656 (#190) was opened at 11:56Z, after the export.
4. **BG0549's merge window is five seconds.** #185 was prepared in batch B run 1 and merged at 08:43:46Z, at the start of run 2. Almost all of that unit's Cursor cost sits in `batch-B-run1` / `overhead:prep`.
5. **Post-merge requests go to the next unit** (window end is exclusive at `merged_at`). A typical merge has two requests just before the merge and a few in the following 90 seconds.
6. **extra-release (PR #175) and BG0682+BG0683 (PR #151, 5 points)** are extra to the 100-point plan. extra-release has its own window (0 plan points). BG0682+BG0683's 5 points cannot be separated from the 08:26 run.
7. **Cache-write is 0** on every sprint Cursor row. Grok-bot rows do have cache-write; it is billed as input.
"""

    (OUT / "BATCH-SUMMARY.md").write_text(md)

    print(f"wrote {req_path} ({len(request_rows)} requests)")
    print(f"wrote {units_path} ({len(unit_rows)} unit rows)")
    print(f"wrote {batches_path}")
    print(f"wrote {OUT / 'BATCH-SUMMARY.md'}")
    print(f"unmatched cursor events: {len(unmatched)}")
    print("\nReconciliation:")
    for line in recon_lines:
        print(line)
    print("\nBatch compact:")
    for row in compact:
        print(" ", row)
    print(f"\nCursor sprint total ${tot_cursor['cost_usd']:.2f} / {tot_cursor['requests']} req")
    print(f"Grok-bot sprint total ${tot_bot['cost_usd']:.2f} / {tot_bot['requests']} req")


if __name__ == "__main__":
    main()
