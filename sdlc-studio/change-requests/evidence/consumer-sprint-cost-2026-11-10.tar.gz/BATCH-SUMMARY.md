# RUN-01M6QYF8 raw cost data (API-equivalent)

Generated from the Cursor usage exports, de-duplicated by Billing Item ID, priced at grok-4.7 API rates (input $2, cached $0.50, output $6 per 1M tokens; cache-write billed as input; 2× when uncached+cached+cache-write ≥ 200k).

## Files

- `requests-by-unit.csv` — one row per cloud-agent (Product=cursor) request in the sprint window (6 Nov 08:06Z through the 10 Nov 11:41Z export).
- `units-summary.csv` — one row per unit window, plus placeholder rows for units whose cost could not be separated.
- `batches-summary.csv` — batch totals for cloud-agent units, overhead, unattributed runs, and grok-bot coordinator usage.
- `windows.json` and `requests_by_unit.py` — the windows and the generator.

`agent_id` is blank: the export has no per-agent column. Attribution is by time window only.

## Batch-level summary (cloud-agent USD, grok-bot separate)

| Batch | Cursor requests | Cursor cost | Of which units | Of which overhead | Of which unattributed | Grok-bot requests | Grok-bot cost |
| --- | --- | --- | --- | --- | --- | --- | --- |
| old-single-agent | 2181 | $282.09 | $103.87 | $21.11 | $157.11 | 1979 | $68.67 |
| batch-A | 321 | $25.72 | $25.04 | $0.68 | $0.00 | 57 | $2.75 |
| batch-B-run1 | 113 | $10.10 | $0.00 | $10.10 | $0.00 | 223 | $8.94 |
| batch-B-run2 | 111 | $12.98 | $12.40 | $0.58 | $0.00 | 55 | $2.03 |
| batch-C | 1 | $0.05 | $0.00 | $0.05 | $0.00 | 7 | $0.14 |
| ALL | 2727 | $330.94 | $141.31 | $32.52 | $157.11 | 2321 | $82.54 |

Grok-bot is coordinator overhead (all of the operator's bots, not only this sprint). It is priced at the same grok-4.7 rates so it can be compared, and is not included in the Cursor / per-unit figures.

## Reconciliation with previously cited figures

- sprint to 74 pts (08:06:00 <= t < 13:40:38 9 Nov, as in the 13:40 export): 2161 requests, $280.63, 630 long-context, first=2026-11-06T08:06:24.933Z, last=2026-11-09T13:37:25.535Z.  vs cited 2161 / $280.63: +0 req, -0.00 USD
- old agent through handoff (08:06:00 <= t < 13:54:49.739): 2181 requests, $282.09, 630 long-context, first=2026-11-06T08:06:24.933Z, last=2026-11-09T13:53:57.611Z.
- batch A (13:54:49.739 <= t < 17:41:32.552) — cited $25.72 / 321: 321 requests, $25.72, 36 long-context, first=2026-11-09T13:54:49.739Z, last=2026-11-09T17:37:41.970Z.  vs cited 321 / $25.72: +0 req, -0.00 USD
- batch A cited window as written (13:56:14 <= t < 17:36:54): 304 requests, $25.10, 36 long-context, first=2026-11-09T13:56:18.662Z, last=2026-11-09T17:36:38.530Z.  vs cited 321 / $25.72: -17 req, -0.62 USD
- batch B run 1 (17:41:32.552 <= t < 08:43:41.659 10 Nov) — cited $9.44 / 110 was t < 18:23:00: 113 requests, $10.10, 10 long-context, first=2026-11-09T17:41:32.552Z, last=2026-11-09T18:23:16.101Z.  vs cited 110 / $9.44: +3 req, +0.66 USD
- batch B run 1 cutoff used for the cited figure (17:40:00 <= t < 18:23:00): 110 requests, $9.44, 7 long-context, first=2026-11-09T17:41:32.552Z, last=2026-11-09T18:22:51.625Z.  vs cited 110 / $9.44: +0 req, -0.00 USD
- batch B run 2 (08:43:41.659 <= t < 11:41:33.474) — cited $12.92 / 110 was t < 11:41:00: 111 requests, $12.98, 30 long-context, first=2026-11-10T08:43:41.659Z, last=2026-11-10T11:41:12.466Z.  vs cited 110 / $12.92: +1 req, +0.06 USD
- batch B run 2 cutoff used for the cited figure (08:43:41.659 <= t < 11:41:00): 110 requests, $12.92, 30 long-context, first=2026-11-10T08:43:41.659Z, last=2026-11-10T11:40:48.583Z.  vs cited 110 / $12.92: +0 req, +0.00 USD
- batch C in this export (11:41:33.474 <= t < 11:42:00): 1 requests, $0.05, 0 long-context, first=2026-11-10T11:41:33.474Z, last=2026-11-10T11:41:33.474Z.

How to read the differences:

- The **$280.63 / 2,161** figure is exact for Cursor usage from 6 Nov 08:06Z to the 9 Nov 13:40Z export cutoff. The old agent's handoff continued until 13:53:57Z, which adds 20 requests and **$1.46** (old-agent Cursor total **$282.09**).
- **Batch A $25.72 / 321** matches when the window is the new agent's first billed request (13:54:49.739Z, a context reset) through 17:37:41Z, i.e. just before batch B run 1. The times quoted earlier (13:56:14Z–17:36:54Z) were slightly tight and omit 17 requests / $0.62 at the two ends.
- **Batch B run 1 $9.44 / 110** matches `t < 18:23:00Z`. The same run has three more requests at 18:23:01–18:23:16 ($0.66), so the full prep run is **113 requests / $10.10**. Those three belong to the run (prompt size still ~212k).
- **Batch B run 2 $12.92 / 110** matches `08:43:41.659Z <= t < 11:41:00Z`. One further request at 11:41:12Z ($0.06) is the same session and is included as batch-B-run2 handoff, so the batch total is **111 requests / $12.98**. The request at 11:41:33Z resets context to 27k and is the only batch-C event in this export ($0.05).
- Nothing was forced to match. Where a cited cutoff and the natural run boundary differ, both are shown.

## Caveats

1. **No per-agent column.** Every Cursor row in this window is grok-4.7-high on a single user principal (plus one empty `grok-bot-default` row at the 6 Nov 08:26:15 stamp, cost $0). Batches and units are assigned by time window only.
2. **Run-start stamping until 9 Nov 08:15Z.** On 6 Nov, 1,011 requests share 08:26:15.773Z and 171 share 11:43:50.956Z. Those runs each cover several merged units, so their cost is in `unattributed:exec-A-08:26` (BG0680, BG0681, BG0488, BG0682+BG0683) and `unattributed:exec-A-11:43` (BG0503, BG0521, BG0522, BG0523). From 9 Nov 08:15Z, and in batches A–C, each request has its own timestamp and merge-to-merge windows are meaningful.
3. **Batch C is not covered.** The export ends at 11:41:55Z. Only the first batch-C Cursor request (11:41:33Z, $0.05) is present. BG0656 (#190) was opened at 11:56Z, after the export.
4. **BG0549's merge window is five seconds.** #185 was prepared in batch B run 1 and merged at 08:43:46Z, at the start of run 2. Almost all of that unit's Cursor cost sits in `batch-B-run1` / `overhead:prep`.
5. **Post-merge requests go to the next unit** (window end is exclusive at `merged_at`). A typical merge has two requests just before the merge and a few in the following 90 seconds.
6. **extra-release (PR #175) and BG0682+BG0683 (PR #151, 5 points)** are extra to the 100-point plan. extra-release has its own window (0 plan points). BG0682+BG0683's 5 points cannot be separated from the 08:26 run.
7. **Cache-write is 0** on every sprint Cursor row. Grok-bot rows do have cache-write; it is billed as input.
